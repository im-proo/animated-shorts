import fs from "node:fs";
import path from "node:path";
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";

if (process.env.REMOTION_TMP) {
  fs.mkdirSync(process.env.REMOTION_TMP, { recursive: true });
  process.env.TEMP = process.env.TMP = process.env.REMOTION_TMP;
}

const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  publicDir: path.resolve("public"),
});

const onBrowserLog = (l) => {
  console.log(`[BROWSER ${l.type.toUpperCase()}]`, l.text);
};

console.log("Selecting composition...");
const composition = await selectComposition({
  serveUrl,
  id: "BridgeShort",
  chromiumOptions: {
    gl: "swiftshader",
  },
  onBrowserLog,
});
console.log("Composition selected:", composition.id);

console.log("Rendering frame 100...");
await renderStill({
  composition,
  serveUrl,
  frame: 100,
  output: "out/test_frame_100.png",
  scale: 0.5,
  chromiumOptions: {
    gl: "swiftshader",
  },
  timeoutInMilliseconds: 60000,
  onBrowserLog,
});
console.log("Frame rendered successfully!");
