import puppeteer from "@remotion/renderer/node_modules/puppeteer/lib/esm/puppeteer/node/PuppeteerNode.js";
import { bundle } from "@remotion/bundler";
import path from "node:path";

const serveUrl = await bundle({
  entryPoint: path.resolve("src/index.ts"),
  publicDir: path.resolve("public"),
});

console.log("Bundle served at:", serveUrl);

const browser = await puppeteer.launch({
  headless: true,
  args: [
    "--no-sandbox",
    "--disable-setuid-sandbox",
    "--disable-dev-shm-usage",
    "--enable-webgl",
    "--use-gl=angle",
    "--use-angle=swiftshader",
  ],
});

const page = await browser.newPage();
page.on("console", (msg) => console.log(`[PAGE ${msg.type()}]`, msg.text()));
page.on("pageerror", (err) => console.error("[PAGE ERROR]", err));
page.on("requestfailed", (req) => console.warn("[REQ FAILED]", req.url(), req.failure()?.errorText));

console.log("Navigating to composition page...");
await page.goto(`${serveUrl}/index.html?composition=BridgeShort`, { waitUntil: "networkidle2", timeout: 30000 }).catch(e => console.error("Goto error:", e.message));

console.log("Checking page state...");
const evaluation = await page.evaluate(() => {
  return {
    rootExists: !!document.getElementById("root"),
    delayHandles: window.remotion_delayRenderTimeouts ? Object.keys(window.remotion_delayRenderTimeouts) : null,
    html: document.body.innerHTML.slice(0, 500),
  };
});
console.log("Page state:", evaluation);

await browser.close();
